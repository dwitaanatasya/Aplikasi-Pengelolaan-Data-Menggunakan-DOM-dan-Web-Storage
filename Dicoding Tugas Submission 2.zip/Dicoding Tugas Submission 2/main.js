(() => {
    let books = JSON.parse(localStorage.getItem("books")) || [];

    function addBook(event) {
        event.preventDefault();

        const titleInput = document.querySelector("#judulBuku");
        const authorInput = document.querySelector("#namaPenulis");
        const yearInput = document.querySelector("#tahunTerbit");
        const isCompleteCheckbox = document.querySelector("#selesaiBaca");

        const book = {
            id: +new Date(),
            title: titleInput.value,
            author: authorInput.value,
            year: parseInt(yearInput.value),
            isComplete: isCompleteCheckbox.checked
        };

        books.push(book);
        updateLocalStorage();
        renderBooks(books);

        titleInput.value = '';
        authorInput.value = '';
        yearInput.value = '';
        isCompleteCheckbox.checked = false;
    }

    function searchBook(event) {
        event.preventDefault();
        const searchTitle = document.querySelector("#cariJudul").value.toLowerCase();
        const filteredBooks = books.filter((book) => book.title.toLowerCase().includes(searchTitle));
        renderBooks(filteredBooks);
    }

    function markAsComplete(event) {
        const id = Number(event.target.id);
        const bookIndex = books.findIndex((book) => book.id === id);
        if (bookIndex !== -1) {
            books[bookIndex].isComplete = true;
            updateLocalStorage();
            renderBooks(books);
        }
    }

    function markAsIncomplete(event) {
        const id = Number(event.target.id);
        const bookIndex = books.findIndex((book) => book.id === id);
        if (bookIndex !== -1) {
            books[bookIndex].isComplete = false;
            updateLocalStorage();
            renderBooks(books);
        }
    }

    function deleteBook(event) {
        const id = Number(event.target.id);
        const bookIndex = books.findIndex((book) => book.id === id);
        if (bookIndex !== -1) {
            books.splice(bookIndex, 1);
            updateLocalStorage();
            renderBooks(books);
        }
    }

    function renderBooks(filteredBooks) {
        const belumSelesai = document.querySelector("#belumSelesai");
        const sudahSelesai = document.querySelector("#sudahSelesai");

        belumSelesai.innerHTML = "";
        sudahSelesai.innerHTML = "";

        filteredBooks.forEach((book) => {
            const bookItem = document.createElement("article");
            bookItem.classList.add("book_item");

            const judul = document.createElement("h3");
            judul.innerText = book.title;

            const penulis = document.createElement("p");
            penulis.innerText = `Penulis: ${book.author}`;

            const tahun = document.createElement("p");
            tahun.innerText = `Tahun: ${book.year}`;

            const actionContainer = document.createElement("div");
            actionContainer.classList.add("action");

            const actionButton = document.createElement("button");
            actionButton.innerText = book.isComplete ? "Belum Selesai dibaca" : "Selesai dibaca";
            actionButton.classList.add(book.isComplete ? "green" : "green");
            actionButton.id = book.id;
            actionButton.addEventListener("click", book.isComplete ? markAsIncomplete : markAsComplete);

            const deleteButton = document.createElement("button");
            deleteButton.innerText = "Hapus buku";
            deleteButton.classList.add("red");
            deleteButton.id = book.id;
            deleteButton.addEventListener("click", deleteBook);

            actionContainer.appendChild(actionButton);
            actionContainer.appendChild(deleteButton);

            bookItem.appendChild(judul);
            bookItem.appendChild(penulis);
            bookItem.appendChild(tahun);
            bookItem.appendChild(actionContainer);

            if (book.isComplete) {
                sudahSelesai.appendChild(bookItem);
            } else {
                belumSelesai.appendChild(bookItem);
            }
        });
    }

    function updateLocalStorage() {
        localStorage.setItem("books", JSON.stringify(books));
    }

    window.addEventListener("load", () => {
        const addBookForm = document.querySelector("#tambahBuku");
        const searchBookForm = document.querySelector("#pencarian");

        addBookForm.addEventListener("submit", addBook);
        searchBookForm.addEventListener("submit", searchBook);

        renderBooks(books);
    });
})();
